# ClosetMuse 🧥✨
**AI closet stylist — capstone project for the 5-Day AI Agents: Intensive Vibe Coding Course With Google**

ClosetMuse looks at photos of the clothes you already own, tags each item's
style automatically, and then plans your outfit for the day by combining
that closet inventory with **live weather** and **your calendar's
occasion** — so you're never stuck picking a floral sundress on a rainy
board-meeting day.

![ClosetMuse card](ui_mockups/00_card_thumbnail.png)

## Why I built this

I own more clothes than I can mentally track, and every morning costs me
the same five minutes of "what fits the weather *and* today's meetings?"
That's a genuinely agentic problem: it needs perception (what's in my
closet, from photos), two independent live-context lookups (weather,
calendar), and a reasoning step that reconciles all three against a
personal style preference — exactly the shape of problem this course spent
five days teaching us to decompose into cooperating agents instead of one
giant prompt.

## Key concepts demonstrated (3 of the required 3+)

| # | Concept | Where |
|---|---|---|
| 1 | **Multi-agent system (Google ADK)** | `agents/stylist_agent.py` composes a `ParallelAgent` (Weather + Calendar, run concurrently since they're independent) feeding a `SequentialAgent` into the Outfit Curator `LlmAgent`. See diagram below. |
| 2 | **MCP server** | `mcp_server/closet_mcp_server.py` exposes the wardrobe/weather/calendar tools over the Model Context Protocol via `FastMCP`, so any MCP client (Claude Desktop, MCP Inspector, another ADK app) can drive ClosetMuse's data layer independently of our own UI. |
| 3 | **Agent skills** | `skills/style_tagging.skill.md` and `skills/outfit_curation.skill.md` are versioned, model-agnostic instruction files (ADK's `skills` module convention) that separate *what the agent should do* from *how it's wired* — swap the model or reorder the pipeline without touching the reasoning spec. |
| bonus | **Security guardrails** | `security/guardrails.py`: upload validation (type/size), prompt-injection screening on untrusted calendar text, PII redaction on model output, and a tool call allow-list enforced via ADK's `before_tool_callback`. |

### Architecture

![Agent architecture](ui_mockups/03_agent_architecture.png)

```
User photo ──▶ Style Vision Agent ──▶ Wardrobe DB (SQLite)
                                            │
Location+Date ─▶ ParallelAgent┬─ Weather Agent ──┐
                               └─ Calendar Agent ─┤
                                                   ▼
                                     Outfit Curator Agent
                                  (outfit_curation.skill.md)
                                                   │
                                                   ▼
                                        Ranked outfit options
```

## Try it in 30 seconds (no API keys needed)

```bash
git clone <your-repo-url>
cd closetmuse
pip install -r requirements.txt
python app.py --plan --location "Hong Kong" --date 2026-07-06
```

This runs the **full pipeline in MOCK_MODE**: a deterministic mock vision
classifier, a seeded mock weather forecast, and a fixed weekly mock
calendar — so reviewers see real multi-agent orchestration logic executing
end-to-end without needing a Gemini/OpenWeather/Google Calendar credential
on hand. Tag your own photos with:

```bash
python app.py --ingest closet/my_blazer.jpg closet/my_boots.jpg
```

Run the test suite (7 tests, all mock-mode, no keys required):
```bash
pytest tests/ -v
```

Try the MCP server standalone:
```bash
pip install mcp
mcp dev mcp_server/closet_mcp_server.py
```

## Going live

Copy `.env.example` to `.env`, set `CLOSETMUSE_MOCK_MODE=false`, and fill in:
- `GOOGLE_API_KEY` — Gemini key for the vision + curator agents
- `OPENWEATHER_API_KEY` — real forecasts
- `GOOGLE_CALENDAR_CREDENTIALS_PATH` — OAuth/service-account for real events
  (wire the actual `google-api-python-client` call into
  `agents/calendar_agent.py::_fetch_real_calendar`)

Then run the real ADK agent via the CLI dev UI:
```bash
adk web
```
which discovers `agents/root_agent.py::root_agent`.

## UI concept

The screens below are static showcase mockups (Pillow-rendered, not a built
front-end) illustrating the intended product — closet library with
auto-generated style tags, and the daily outfit generator that surfaces the
weather + calendar reasoning behind each suggestion.

| Closet Library | Today's Outfit |
|---|---|
| ![Closet](ui_mockups/01_closet_library.png) | ![Outfit](ui_mockups/02_outfit_generator.png) |

Palette: `#F0EDDC` cream · `#B9AC8C` tan · `#845F4A` espresso · `#DFA0AA`
blush. Display font: a classy script standing in for "Lavonia" (bundled as
Dancing Script, since Lavonia is a commercial font not redistributable in
an open repo). Body font: **Nunito**. Regenerate the mockups anytime with
`python ui_mockups/generate_mockups.py`.

## Project layout

```
closetmuse/
├── app.py                          # CLI demo runner (MOCK_MODE by default)
├── config.py                       # theme tokens, mock-mode, taxonomy
├── agents/
│   ├── vision_style_agent.py       # garment photo → structured tags
│   ├── weather_agent.py            # weather tool + ADK agent wrapper
│   ├── calendar_agent.py           # calendar tool + occasion inference
│   ├── stylist_agent.py            # ADK Parallel+Sequential orchestrator
│   ├── wardrobe_manager.py         # SQLite closet persistence
│   └── root_agent.py               # `adk web` / `adk run` entry point
├── mcp_server/closet_mcp_server.py # tools exposed over MCP
├── security/guardrails.py          # upload/PII/injection/allow-list guards
├── skills/*.skill.md               # agent skill specs
├── ui_mockups/                     # generator script + rendered PNGs
└── tests/test_agents_smoke.py      # 7 mock-mode smoke tests
```

## Roadmap (post-hackathon)

- Real front-end (React Native) wired to the same Python agent backend.
- Swap the SQLite wardrobe for per-user cloud storage + auth.
- Add a "laundry rotation" agent that nudges you to re-wear neglected pieces.
- Feedback loop: `record_outfit_feedback` already stubs the wiring for a
  future preference-learning agent.

---
Built for the *5 Days AI Agents: Intensive Vibe Coding Course With Google*
capstone (Kaggle, July 2026).
