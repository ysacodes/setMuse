"""
ClosetMuse demo runner.

    python app.py --ingest closet/*.jpg      # tag new photos into the closet
    python app.py --plan --location "Hong Kong" --date 2026-07-06

Runs entirely in MOCK_MODE by default (see config.py) — no API keys needed
to see the full multi-agent pipeline (vision tagging -> weather + calendar
context gathering -> outfit curation) end to end.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json

from agents.stylist_agent import plan_todays_outfits
from agents.vision_style_agent import classify_garment
from agents.wardrobe_manager import Garment, WardrobeManager
from config import MOCK_MODE


def cmd_ingest(paths: list[str]) -> None:
    wardrobe = WardrobeManager()
    for path in paths:
        attrs = classify_garment(path)
        garment_id = wardrobe.add_garment(Garment(id=None, image_path=path, **attrs))
        print(f"[ingested #{garment_id}] {path} -> {attrs}")


def cmd_plan(location: str, date_iso: str) -> None:
    wardrobe = WardrobeManager()
    wardrobe.seed_demo_closet()
    plan = plan_todays_outfits(wardrobe, location, date_iso)

    print(f"\n📍 {plan['weather']['location']}  |  📅 {plan['calendar']['date']}")
    print(f"🌤️  {plan['weather']['temperature_c']}°C, {plan['weather']['condition']} "
          f"({plan['weather']['precipitation_chance']}% precip) — season: {plan['weather']['season']}")
    print(f"🗓️  Events: {', '.join(plan['calendar']['events'])}")
    print(f"🎯 Inferred occasion: {plan['calendar']['occasion']}\n")

    for i, outfit in enumerate(plan["outfits"], 1):
        print(f"--- Outfit option {i} ---")
        for piece in outfit["pieces"]:
            print(f"   • {piece}")
        print(f"   why: {outfit['rationale']}\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ClosetMuse capstone demo")
    parser.add_argument("--ingest", nargs="+", help="Image paths to tag and add to the closet")
    parser.add_argument("--plan", action="store_true", help="Generate today's outfit options")
    parser.add_argument("--location", default="Hong Kong")
    parser.add_argument("--date", default=dt.date.today().isoformat())
    args = parser.parse_args()

    print(f"[ClosetMuse] MOCK_MODE={MOCK_MODE}\n")

    if args.ingest:
        cmd_ingest(args.ingest)
    if args.plan or not args.ingest:
        cmd_plan(args.location, args.date)
