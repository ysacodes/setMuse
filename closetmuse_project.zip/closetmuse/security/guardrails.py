"""
Security features for ClosetMuse.

This is the concept-3 requirement for the capstone ("security features").
ADK exposes callback hooks at several points in an agent's lifecycle
(before_model, before_tool, after_model, after_tool). We use them to add:

  1. Upload validation      — reject oversized / non-image files before they
                               ever reach the vision model (cost + abuse guard).
  2. Prompt-injection screen — calendar event titles / descriptions are
                               untrusted third-party text (anyone can invite
                               you to a calendar event). We scan them for
                               instruction-like patterns before they're
                               concatenated into a model prompt.
  3. PII redaction on output — outfit rationales should never echo back raw
                               calendar text (attendee emails, addresses).
  4. Tool allow-list         — the Stylist agent may only call the four tools
                               it was explicitly wired with; anything else is
                               blocked at the callback layer as defense in
                               depth on top of ADK's normal tool binding.

These are plain functions so they're easy to unit-test in isolation, and are
attached to agents via `before_model_callback` / `before_tool_callback` in
agents/root_agent.py.
"""
from __future__ import annotations

import os
import re
from typing import Any

from config import ALLOWED_IMAGE_EXT, MAX_UPLOAD_MB

_INJECTION_PATTERNS = [
    r"ignore (all|previous|the) instructions",
    r"you are now",
    r"system prompt",
    r"disregard (all|your) (rules|guidelines)",
    r"reveal (the|your) (prompt|instructions)",
]
_PII_PATTERNS = [
    r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+",   # email
    r"\b\d{3}[-.\s]?\d{3}[-.\s]?\d{4}\b",                 # phone
]

ALLOWED_TOOL_NAMES = {
    "get_weather_forecast",
    "get_todays_calendar_events",
    "list_wardrobe_items",
    "record_outfit_feedback",
}


class SecurityRejection(Exception):
    """Raised when a guardrail blocks a request; caught by the runner and
    surfaced to the user as a friendly message instead of a stack trace."""


def validate_upload(file_path: str) -> None:
    """Guard 1 — runs before any image reaches the vision agent."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext not in ALLOWED_IMAGE_EXT:
        raise SecurityRejection(f"Unsupported file type '{ext}'.")
    size_mb = os.path.getsize(file_path) / (1024 * 1024) if os.path.exists(file_path) else 0
    if size_mb > MAX_UPLOAD_MB:
        raise SecurityRejection(f"Image is {size_mb:.1f}MB; limit is {MAX_UPLOAD_MB}MB.")


def screen_for_injection(text: str) -> str:
    """Guard 2 — scrub / flag untrusted text (calendar titles, garment notes)
    before it is folded into an LLM prompt. Returns a sanitized string;
    raises if the text looks like an outright injection attempt."""
    lowered = text.lower()
    for pattern in _INJECTION_PATTERNS:
        if re.search(pattern, lowered):
            raise SecurityRejection(
                "Blocked untrusted calendar text that resembled a prompt injection."
            )
    return text


def redact_pii(text: str) -> str:
    """Guard 3 — applied to any agent output before it's shown to the user."""
    redacted = text
    for pattern in _PII_PATTERNS:
        redacted = re.sub(pattern, "[redacted]", redacted)
    return redacted


def enforce_tool_allowlist(tool_name: str) -> None:
    """Guard 4 — attach as a before_tool_callback on the Stylist agent."""
    if tool_name not in ALLOWED_TOOL_NAMES:
        raise SecurityRejection(f"Tool '{tool_name}' is not on the Stylist allow-list.")


# --- ADK callback adapters -------------------------------------------------
# ADK callbacks receive (callback_context, llm_request) / (tool, args, tool_context)
# style signatures depending on version. We keep the adapters thin so the
# guardrail logic above stays framework-agnostic and unit-testable.

def before_tool_callback(tool, args: dict, tool_context: Any = None):
    enforce_tool_allowlist(getattr(tool, "name", str(tool)))
    for value in args.values():
        if isinstance(value, str):
            screen_for_injection(value)
    return None  # returning None tells ADK to proceed with the tool call


def after_model_callback(callback_context: Any, llm_response: Any):
    if hasattr(llm_response, "text") and llm_response.text:
        llm_response.text = redact_pii(llm_response.text)
    return llm_response
