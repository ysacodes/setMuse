"""
ClosetMuse MCP Server — Concept 2 (MCP servers).

Exposes the same tool functions the in-process ADK agents use
(get_weather_forecast, get_todays_calendar_events, list_wardrobe_items,
record_outfit_feedback) over the Model Context Protocol, so:

  - Any MCP-compatible client (Claude Desktop, the MCP Inspector, another
    ADK app via google.adk.tools.mcp_tool) can drive ClosetMuse's data
    layer directly, independent of our own Stylist agent.
  - Judges can `mcp dev mcp_server/closet_mcp_server.py` and poke at the
    tools interactively without touching any UI code.

Run:
    pip install mcp
    mcp dev mcp_server/closet_mcp_server.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.append(str(Path(__file__).resolve().parents[1]))  # allow `import config`, `import agents.*`

from mcp.server.fastmcp import FastMCP

from agents.calendar_agent import get_todays_calendar_events
from agents.wardrobe_manager import WardrobeManager
from agents.weather_agent import get_weather_forecast
from security.guardrails import SecurityRejection, enforce_tool_allowlist

mcp = FastMCP("closetmuse")


@mcp.tool()
def get_weather(location: str, date_iso: str) -> dict:
    """Get the weather forecast for a location and date (YYYY-MM-DD)."""
    enforce_tool_allowlist("get_weather_forecast")
    return get_weather_forecast(location, date_iso)


@mcp.tool()
def get_calendar_events(date_iso: str) -> dict:
    """Get today's calendar events and inferred occasion for a date (YYYY-MM-DD)."""
    enforce_tool_allowlist("get_todays_calendar_events")
    try:
        return get_todays_calendar_events(date_iso)
    except SecurityRejection as e:
        return {"error": str(e)}


@mcp.tool()
def list_wardrobe_items(garment_type: str | None = None) -> list[dict]:
    """List garments in the closet library, optionally filtered by type
    (dress, top, bottom, outerwear, shoes, accessory, set)."""
    enforce_tool_allowlist("list_wardrobe_items")
    wardrobe = WardrobeManager()
    wardrobe.seed_demo_closet()
    return [g.to_row() | {"id": g.id} for g in wardrobe.list_garments(garment_type)]


@mcp.tool()
def record_outfit_feedback(garment_ids: list[int], liked: bool) -> dict:
    """Record that an outfit (list of garment ids) was worn/liked, so future
    recommendations rotate away from overused pieces."""
    enforce_tool_allowlist("record_outfit_feedback")
    wardrobe = WardrobeManager()
    for gid in garment_ids:
        wardrobe.mark_worn(gid)
    return {"status": "recorded", "garment_ids": garment_ids, "liked": liked}


if __name__ == "__main__":
    mcp.run()
